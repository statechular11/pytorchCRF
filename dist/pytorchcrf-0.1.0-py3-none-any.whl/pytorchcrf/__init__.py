#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .pytorch_crf import CRF
